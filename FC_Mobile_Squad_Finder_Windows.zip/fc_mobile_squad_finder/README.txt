# FC Mobile Squad Finder — Windows starter

## Run it
1. Install Python 3 from https://www.python.org/downloads/ (enable "Add Python to PATH").
2. Extract this ZIP.
3. Double-click `START.bat`.
4. Open http://localhost:8000 in Chrome or Edge.

## Current status
This is a working local website shell with a UID form and squad-results UI. The API route currently returns HTTP 501 because no verified public FC Mobile UID-to-squad endpoint has been established. It does not fabricate squad data.

## Important API limitation
EA's public FC Community API access is restricted to approved partners and is not a general public UID lookup API. Community reverse-engineering projects for console/PC Ultimate Team are not proof of FC Mobile compatibility. Do not enter EA passwords or session tokens into unofficial sites.

To enable real lookups, a lawful and technically verified FC Mobile data provider must be identified and integrated in `server.py`.
